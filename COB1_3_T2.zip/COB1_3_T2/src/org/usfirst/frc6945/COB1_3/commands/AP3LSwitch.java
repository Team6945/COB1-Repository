package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;


/** AP[1]h[2]s[3]
 * 1: P = position, so 1=left side, 2=middle, and 3 = right side
 * 2:  L=left side, and R=right side
 */
public class AP3LSwitch extends CommandGroup {

	public AP3LSwitch() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	
    	addSequential(new Drive(48));	
    	addSequential(new Turn(-90));
    	addSequential(new Drive(160));	
    	addSequential(new Turn(90));
    	addSequential(new Drive(80));	
    	addSequential(new Switch());
    	
	}

	

}
