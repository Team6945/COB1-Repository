package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;


public class ScaleLeft extends CommandGroup {

	public ScaleLeft() {

    	requires(Robot.blockSucker);
    	requires(Robot.wristPID);
    	requires(Robot.lift);
    	
    	addSequential(new Turn(30));
    	addSequential(new LiftControl(0.65));
    	addSequential(new WristSetpoint(50));
    	addSequential(new BSInOrOut(-1, 1.0));
    	addSequential(new WristSetpoint(10));
    	addSequential(new LiftControl(-0.65));
    	
    	
	}

	

}
