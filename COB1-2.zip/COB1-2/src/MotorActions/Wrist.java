package MotorActions;

public class Wrist extends Motors{
	
	public static void Angle(double angle) {
		
	}
}
