package MotorActions;

public class Drive extends Motors{

	public static void DifDrive(double forward, double turn) {
		//add sensor check for slippage
		drive.arcadeDrive(forward, turn);
	}
}
