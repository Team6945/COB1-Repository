package MotorActions;

import edu.wpi.first.wpilibj.Timer;

public class Winch extends Motors{

	static final double C = 1;/** Height/k = Time, so K= x Ft /1 Second */
	static final double height = 7; //CHECK THIS HEIGHT

	
	static Timer timer = new Timer();
	
	
	public static void FullControl(double value) {
		_scissorLift1.set(value); /* Negate if switched. */ 
	}

	public static void Up() {
		timer.start();
		if (timer.get() < (height/C)) {	
			_scissorLift1.set(0.25);
		} else {
			_scissorLift1.set(0);
		}
		timer.reset();
	}
	
	public static void Down() {
		timer.start();
		if (timer.get() < (height/C)) {	
			_scissorLift1.set(-0.25);
		} else {
			_scissorLift1.set(0);
		}
		timer.reset();
	}
	
	
	
}
