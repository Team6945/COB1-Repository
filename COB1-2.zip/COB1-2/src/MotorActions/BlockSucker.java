package MotorActions;

public class BlockSucker extends Motors {

	public static void Suck(boolean in) {
    	if(in)_blockSucker.set(1.0); // negate the value to change direction if incorrect
    	else _blockSucker.set(0);
    	
	}
	
	public static void Spit(boolean out) {
    	if(out)_blockSucker.set(-1.0); // negate the value to change direction if incorrect
    	else _blockSucker.set(0);
    	
	}
	
	
}
