package MotorActions;

import edu.wpi.first.wpilibj.Timer;

public class ScissorLift extends Motors{

	static final double K = 1;/** Height/k = Time, so K= x Ft /1 Second */
	static final double CUBE = 13/12; // height of block/ 1 ft
	static double time;
	
	static Timer liftTimer = new Timer();
	
	
	public static void FullControl(double value) {
		_scissorLift1.set(value); /* Negate if switched. */ 
	}
	
	private static void Lift(double height) {//Scale - start 5ft, 4ft, 6ft
		liftTimer.start();
		if (liftTimer.get() < (height/K)) {	
			_scissorLift1.set(0.25);
		} else {
			_scissorLift1.set(0);
		}
		liftTimer.reset();
	}
	
	/** 
	 * Add height needed for block
	 */
	
	public static void ScaleHigh() {//Scale - start 5ft, 4ft, 6ft
		Lift(6+CUBE);
		
	}
	
	public static void ScaleMid() {//Scale - start 5ft, 4ft, 6ft
		Lift(5+CUBE);
		
	}
	
	public static void ScaleLow() {//Scale - start 5ft, 4ft, 6ft
		Lift(4+CUBE);
	}
	
	public static void Switch() {//Switch - wall 2ft, switch - 9in at start 
		Lift(2+CUBE);
	}
	
	public static void EndGameBar() {
		Lift(7+CUBE);
	}
}
