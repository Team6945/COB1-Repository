package org.usfirst.frc.team6945.robot;

import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import MotorActions.BlockSucker;
import MotorActions.Drive;
import MotorActions.ScissorLift;

public class Controller extends Motors {

	static Joystick joy = new Joystick(0);
	static Joystick controller = new Joystick(1);
	
	public static void SDashboard() {
		SmartDashboard.putNumber("D-Pad", controller.getPOV());
		
	}
	
	public static void BlockSuckerOut() {
		//JoystickButton LB = new JoystickButton(controller, 5);
		//LB.whileHeld(_blockSucker.set(1.0));
		
		boolean blockOutLB = controller.getRawButton(5); 
		if(blockOutLB)_blockSuckerR.set(1.0);//only runs if button to suck is not pressed
    	//if(!(blockOutLB))_blockSuckerR.set(0);//sets to zero when button is not pressed
    	
    	if(blockOutLB)_blockSucker.set(-1.0);//only runs if button to suck is not pressed
    	//if(!(blockOutLB))_blockSucker.set(0);//sets to zero when button is not pressed
	}
	public static double Trunk(double value) {
		int temp =(int)value*10;
		return (double)temp/10;
		
	}
	public static void BlockSuckerIn() {
    	
		//double blockIn = Trunk(controller.getRawAxis(5));
		
		//_blockSucker.set(blockIn);
		//_blockSuckerR.set(-blockIn);
		
		/*
		if(blockIn)_blockSucker.set(1.0);
		if(blockIn)_blockSuckerR.set(-1.0);
		
		if(blockOut)_blockSucker.set(1.0);
		if(blockOut)_blockSuckerR.set(-1.0);	
		*/
		
		boolean blockInRB = controller.getRawButton(6);
    	
    	   	
    	
    	if(blockInRB)_blockSuckerR.set(-1.0); // negate the value to change direction if incorrect
    	//if(!(blockInRB)) _blockSuckerR.set(0);
    	
    	if(blockInRB)_blockSucker.set(1.0);//only runs if button to suck is not pressed
    	//if(!(blockInRB)) _blockSucker.set(0);//sets to zero when button is not pressed
    	
    	/*if(blockOutLB)_blockSuckerR.set(1.0);//only runs if button to suck is not pressed
    	if(!(blockOutLB))_blockSuckerR.set(0);//sets to zero when button is not pressed
    	
    	if(blockOutLB)_blockSucker.set(-1.0);//only runs if button to suck is not pressed
    	if(!(blockOutLB))_blockSucker.set(0);//sets to zero when button is not pressed
    	*/
    	
    	//_blockSucker.set(controller.getThrottle()/3);
		//_blockSuckerR.set(controller.getTwist()/3);
		
	}
	
	
	public static void DriveTrain() {
		double forward = joy.getY(); // logitech gampad left X, positive is forward
    	double turn = joy.getX(); //logitech gampad right X, positive means turn right
    	
    	drive.arcadeDrive(forward, turn); // if statement prevents multiplying motor power by more than 100% (1.0)
    	drive2.arcadeDrive(forward, turn);
	}
	
	
	public static void ScissorLift() {
		double lift = Trunk(controller.getY());
		
		//ScissorLift.ScaleHigh();
			//controller.getRawButton(2);
			
		
		
		_scissorLift1.set(0.75*lift);
		_scissorLift2.set(0.75*lift);
		/* Negate if switched. 
		Could be altered to a button method (see BlockSucker above)
		 with a set height. Will need to import timer into this class,
		 and send the m_timer into this method from the Robot class.*/ 
		
	}
	
	public static void Wrist() {
		double twist = controller.getZ();
		_wrist.set(1*twist);
	}
	
	public static void Winch() {
		boolean pull = joy.getRawButton(4);
		_winch.set(0);
	}
	
}
