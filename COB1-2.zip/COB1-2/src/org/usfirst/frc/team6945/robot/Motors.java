package org.usfirst.frc.team6945.robot;

import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;


public class Motors {

	static WPI_TalonSRX _frontLeftMotor = new WPI_TalonSRX(4); 		/* device IDs here */
	static WPI_TalonSRX _frontRightMotor = new WPI_TalonSRX(2);
	static WPI_TalonSRX _backLeftMotor = new WPI_TalonSRX(1);
	static WPI_TalonSRX _backRightMotor = new WPI_TalonSRX(3);	
	static WPI_TalonSRX _scissorLift1 = new WPI_TalonSRX(6);
	static WPI_TalonSRX _scissorLift2 = new WPI_TalonSRX(5);
	static WPI_TalonSRX _blockSucker = new WPI_TalonSRX(9);		// Left block sucker
	static WPI_TalonSRX _blockSuckerR = new WPI_TalonSRX(10); //Change IDs accordingly
	static WPI_TalonSRX _wrist = new WPI_TalonSRX (7);
	static WPI_TalonSRX _winch = new WPI_TalonSRX (8);
	
	//Motor controller for the winch?
	
	static DifferentialDrive drive = new DifferentialDrive( _frontRightMotor,_frontLeftMotor);
	
	static DifferentialDrive drive2 = new DifferentialDrive( _backRightMotor,_backLeftMotor);
	
	
	
	
}
