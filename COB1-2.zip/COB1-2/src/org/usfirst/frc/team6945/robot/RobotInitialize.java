package org.usfirst.frc.team6945.robot;

public class RobotInitialize extends Motors {

	public static void SetFollows() {
		_backLeftMotor.follow(_frontLeftMotor);
    	_backRightMotor.follow(_frontRightMotor);
    	
    	_scissorLift2.follow(_scissorLift1);
    	
    	_blockSuckerR.follow(_blockSucker);//If one motor is reversed, take this out and add a line for _blockesuckerR in each class
	}
	
}

//This probably doesn't do anything right now but I'm going to keep it for the time being anyway.
