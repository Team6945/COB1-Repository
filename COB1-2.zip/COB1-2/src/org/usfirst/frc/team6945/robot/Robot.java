package org.usfirst.frc.team6945.robot;

import com.ctre.phoenix.motorcontrol.can.*;

import edu.wpi.first.wpilibj.BuiltInAccelerometer;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.PIDSubsystem;
import com.analog.adis16448.frc.ADIS16448_IMU;

import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.IterativeRobot;


import MotorActions.Motors;
import MotorActions.Wrist;
import MotorActions.Winch;

//Yellow Underlines are because imports are not used in this main class.


/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */

public class Robot extends IterativeRobot {	
	
	
	
	Timer m_timer = new Timer();

	int secondsPerMeter; 
    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */

    public void robotInit() {
    	
    	RobotInitialize.SetFollows();
    	
    	CameraServer.getInstance().startAutomaticCapture();
    }


	/**
	 * This function is run once each time the robot enters autonomous mode.
	 */
	@Override
	public void autonomousInit() {
		m_timer.reset(); 
		m_timer.start(); //starts the timer used in the AutoMode methods.
	}

	public static double Trunk(double value) {
		int temp =(int)value*10;
		return (double)temp/10;
		
	}
	
	public static final ADIS16448_IMU imu = new ADIS16448_IMU();
	  
	  @Override
	  public void robotPeriodic() {  
		  
	    SmartDashboard.putNumber("Gyro-X", imu.getAngleX());
	    SmartDashboard.putNumber("Gyro-Y", imu.getAngleY());
	    SmartDashboard.putNumber("Gyro-Z", imu.getAngleZ());
	    
	    SmartDashboard.putNumber("Accel-X", imu.getAccelX());
	    SmartDashboard.putNumber("Accel-Y", imu.getAccelY());
	    SmartDashboard.putNumber("Accel-Z", imu.getAccelZ());
	    
	    SmartDashboard.putNumber("Pitch", imu.getPitch());
	    SmartDashboard.putNumber("Roll", imu.getRoll());
	    SmartDashboard.putNumber("Yaw", imu.getYaw());
	    
	    SmartDashboard.putNumber("Pressure: ", imu.getBarometricPressure());
	    SmartDashboard.putNumber("Temperature: ", imu.getTemperature()); 
	    
	    SmartDashboard.putNumber("Right Y axis: ", Trunk(Controller.controller.getRawAxis(5))); 
	    SmartDashboard.putNumber("Left Y axis: ", Trunk(Controller.controller.getRawAxis(1))); 
	    SmartDashboard.putNumber("Left X axis: ", Trunk(Controller.controller.getRawAxis(0))); 
	    SmartDashboard.putNumber("Right X axis: ", Trunk(Controller.controller.getRawAxis(4))); 
	    SmartDashboard.putNumber("Left Trigger axis: ", Trunk(Controller.controller.getRawAxis(2))); 
	    SmartDashboard.putNumber("Right Trigger axis: ", Trunk(Controller.controller.getRawAxis(3)));
	    
	    SmartDashboard.putNumber("Twist: ", Controller.controller.getTwist()); 
	    SmartDashboard.putNumber("Throttle: ", Controller.controller.getThrottle());
	    SmartDashboard.putNumber("Z Channel: ", Controller.controller.getZChannel()); 
	    SmartDashboard.putNumber("Axis Count: ", Controller.controller.getAxisCount()); 
	    SmartDashboard.putBoolean("Top: ", Controller.controller.getTop()); 
	    SmartDashboard.putBoolean("Top Pressed: ", Controller.controller.getTopPressed());
	    SmartDashboard.putBoolean("Top Released: ", Controller.controller.getTopReleased());

	    
	    
	    
	    Controller.SDashboard();
	  }

	/**
	 * This function is called periodically during autonomous.
	 */
	@Override
	public void autonomousPeriodic() {
		
		AutoMode.Auto1(m_timer);
		
	}



    /**
     * This function is called periodically during operator control
     */

    public void teleopPeriodic() {
    	
    	Thread blockSuckIn = new Thread(() -> {
    		Controller.BlockSuckerIn();
    	});
    	Thread blockSuckOut = new Thread(() -> {
    		Controller.BlockSuckerOut();
    	});
    	
    	blockSuckIn.start();
    	blockSuckOut.start();
    	
    	//Controller.BlockSuckerIn();	//gives control of the sucker motors //CHECK IDS, AND TEST!!!
    	//Controller.BlockSuckerOut();
    	Controller.DriveTrain();	//gives control of the Drive Train   //TEST!!
    	Controller.ScissorLift(); //gives control of the ScissorLift motor //CHECK ID, AND TEST!!
    	Controller.Wrist();
    	Controller.Winch();
    	
    }

}