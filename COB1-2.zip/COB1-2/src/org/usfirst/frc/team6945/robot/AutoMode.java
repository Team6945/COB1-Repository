package org.usfirst.frc.team6945.robot;

import edu.wpi.first.wpilibj.Encoder;

import edu.wpi.first.wpilibj.Timer;

public class AutoMode extends Motors {

		
	public static void Auto1(Timer m_timer) {
		
    	_backLeftMotor.follow(_frontLeftMotor);
    	_backRightMotor.follow(_frontRightMotor);
		
		if (m_timer.get() < (5.0)) {
			drive.arcadeDrive(0.5, 0.0); // drive forwards half speed
			drive2.arcadeDrive(0.5, 0.0);
			
			Encoder enc;
			enc = new Encoder(0, 1, false, Encoder.EncodingType.k4X);
			
			enc.setMaxPeriod(.1);
			enc.setMinRate(10);
			enc.setDistancePerPulse(5);
			enc.setReverseDirection(true);
			enc.setSamplesToAverage(7);
			
			int count = enc.get();
			double distance = enc.getRaw();
			double distance2 = enc.getDistance();
			double period = enc.getPeriod(); //Deprecated, FRC suggests using rate
			double rate = enc.getRate();
			boolean direction = enc.getDirection();
			boolean stopped = enc.getStopped();

			
			//set up encoder stuff, 1.Drive to location, cross line 2.Scissor lift? 3.Aim Block Correctly 
			//4.If not scissor lift, then shoot block into scale, or drop 5. ?????????? 6.Profit
			
			//_scissorLift1.set(-0.25);
			
			_blockSucker.set(-0.25);
			
		} else {
			drive.stopMotor(); // stop robot
			drive2.stopMotor();
			_scissorLift1.set(0);
			
		}
	}
}
