package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP1LSwitch extends CommandGroup {

	public AP1LSwitch() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,23}
				,{14,23}
				,{14,20}
    	};
    	
    	double timeToComplete = 5;
    	
    	addSequential(new AutoPath(path, timeToComplete,true));	//Drive is in inches
    	addSequential(new Switch());
    	
	}

	

}
