package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class TenFeet extends CommandGroup {

	public TenFeet() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{0,4}
				,{10,4}
    	};
    	
    	double timeToComplete = 5;
    	
    	addSequential(new AutoPath(path, timeToComplete,true));	//Drive is in inches
  
    	/**should go 10 ft.
    	 * 10/distanceTravelled = K
    	 * maxV_WhenTested * K = new_maxV
    	 */
    	
	}

	

}
