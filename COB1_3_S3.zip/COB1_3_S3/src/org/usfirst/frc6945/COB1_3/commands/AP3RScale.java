package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP3RScale extends CommandGroup {

	public AP3RScale() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,4}
				,{19,4}
				,{24,5}
    	};
    	
    	double timeToComplete = 8;
    	
    	addSequential(new AutoPath(path, timeToComplete, true));	//Drive is in inches
    	
    	addSequential(new LiftControl(1));
    	addSequential(new Switch());
    	
    	
	}

	

}
