package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP3LScale extends CommandGroup {

	public AP3LScale() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,4}
				,{20,4}
				,{19,21}
				,{24,21}
    	};
    	
    	double timeToComplete = 11;
    	
    	addSequential(new AutoPath(path, timeToComplete, true));	//Drive is in inches
    
    	addSequential(new LiftControl(1));
    	addSequential(new Switch());
    	
    	
	}

	

}
