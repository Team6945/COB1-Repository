package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP1LScale extends CommandGroup {

	public AP1LScale() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,23}
				,{19,23}
				,{24,22}
    	};
    	
    	double timeToComplete = 7;
    	
    	addSequential(new AutoPath(path, timeToComplete, true));	//Drive is in inches
    	
    	addSequential(new LiftControl(1));
    	addSequential(new Switch());
    	
    	
	}

	

}
