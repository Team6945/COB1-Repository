
public class PlotSmoothPath {

	public static void main(String[] args) {
		double[][] testPath = {
				{1,11.5}
				,{4,11.5}
				,{7,9.5}
				,{11.5,9.5}
		};

		double totalTime = 4; //seconds. Play with this.
		
		boolean velocityGraph = true; // true, if you want to see a graph of the speeds over time
		
		
		
		
		double timeStep = 0.1; // period of control loop on Rio, seconds. SET THIS IN AUTOPATH COMMAND
		double robotTrackWidth = 2.75; //distance between left and right wheels, feet. DO NOT CHANGE
		
		
		//TODO Runs graphs and values. 
		FalconPathPlanner pathPlan = new FalconPathPlanner(testPath);
		pathPlan.PowerUpField(totalTime, timeStep, robotTrackWidth, velocityGraph);
		
	}
	/**(*autonomous* Command )
1. A 2D double array 'path' is created with the coordinates of the waypoints for the autopath.
2. 'timeToComplete' is initialized at 7 seconds. 
3. Both variables ar sent to command 'AutoPath' as parameters. 

(AutoPath Command)
4. AutoPath assigns 'maxV' (the velocity of the robot when drive motors are at 1.0)
5. path is assinged to the field varialbe path, and timeToComplete is assigned to the endTime field variable
6. Initialize is run when command is called in autonomous, which runs drivetrain.startPath with the parameters path, endTime, and maxV

(Drivetrain Subsystem)
7. startPath sets a field variable maxVelocity to maxV, totalPathTime to endTime, and timestep to every 0.1 second and robot track width to 2.6
8. FalconPathPlanner autoPath is initialized with parameter 'path' 2D array
9. The smooth path is calculated (.calculate(*parameters*)) with totalPathTime, timeStep, and robotTrackWidth.
10. The drivetrain timer is reset and started. 

(AutoPath Command)
11. execute() is run the next (or current) loop (and until isFinished() returns true)
12. This runs Robot.drivetrain.runPath

(Drivetrain Subsystem)
13. runPath runs pathLeft first, then pathRight (same, except right vs left)
14. speed is initialized to 0, as a precaution
15. a for loop steps through each 1D array in autoPath.smoothLeftVelocity.
16. if the time (array[i][0], or num[0] at current loop step) is less
 than the current time, speed is set to the speed at that interval (array[i][1], or num[1])
   - the speed at the interval is divided by the max speed if the speed is less then the max speed
     since the motors receive values from 0.0 to 1.0 
   - if the speed is greater than the interval, the speed is set to 1.0
17. The leftMotors SpeedController is set to 1.0

18. isFinished checks pathFinished in drivetrain

19. pathFinished sends true if totalPathTime is less then the current time on the timer

	 */

}
