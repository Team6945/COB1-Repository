package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;


/** Auto[1]h[2]s[3]
 * 1: R=red, B = Blue, maybe not necessary
 * 2: h= High Scale	, so L=left side, and R=right side
 * 3: s=Short Switch, so L=left side, and R=right side
 */
public class AP2RSwitch extends CommandGroup {

	public AP2RSwitch() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	
    	addSequential(new Turn2(12)); //turns towards the switch
    	addSequential(new Drive(113));	//drives towards the switch
    	addSequential(new Turn2(-12));
    	addSequential(new Switch());	//shoots block
    
    	
	}

	

}
