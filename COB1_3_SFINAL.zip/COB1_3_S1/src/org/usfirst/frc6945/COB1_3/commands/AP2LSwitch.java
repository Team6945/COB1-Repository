package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP2LSwitch extends CommandGroup {

	public AP2LSwitch() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,11.5}
				,{4,11.5}
				,{8,18}
				,{11.5,18}
    	};
    	
    	double timeToComplete = 5;
    	
    	addSequential(new AutoPath(path, timeToComplete));	//Drive is in inches
    	
    	
	}

	

}
