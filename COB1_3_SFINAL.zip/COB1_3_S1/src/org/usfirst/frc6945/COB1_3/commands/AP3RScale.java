package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP3RScale extends CommandGroup {

	public AP3RScale() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,5}
				,{10,3}
				,{23,3}
				,{27,3}
    	};
    	
    	double timeToComplete = 6;
    	
    	addSequential(new AutoPath(path, timeToComplete));	//Drive is in inches
    	addSequential(new Turn(-90));
    	addSequential(new LiftControl(1));
    	addSequential(new Switch());
    	
    	
	}

	

}
