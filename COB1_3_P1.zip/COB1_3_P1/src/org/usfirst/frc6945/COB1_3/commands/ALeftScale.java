package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;


/** Auto[1]h[2]s[3]
 * 1: R=red, B = Blue, maybe not necessary
 * 2: h= High Scale	, so L=left side, and R=right side
 * 3: s=Short Switch, so L=left side, and R=right side
 */
public class ALeftScale extends CommandGroup {

	public ALeftScale() {
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	addSequential(new ScaleLeft(1));
    	addSequential(new Turn(-90));
    	addSequential(new Drive(30));
    	addSequential(new Turn(-180));
    	addSequential(new Drive(97.75));
    	
    	
	}

	

}
