package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;


public class ScaleLeft extends CommandGroup {

	public ScaleLeft(double speed) {

    	requires(Robot.blockSucker);
    	requires(Robot.wristPID);
    	requires(Robot.lift);
    	
    	addSequential(new Turn(-90));
    	addSequential(new LiftControl(1));
    	addSequential(new WristSetpoint(135));
    	addSequential(new BSInOrOut(speed, 1.0));
    	addSequential(new WristSetpoint(90));
    	addSequential(new LiftControl(-1));
    	
    	
	}

	

}
