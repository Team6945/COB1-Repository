package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP2RSwitch extends CommandGroup {

	public AP2RSwitch() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,13}
				,{4,13}
				,{7,9}
				,{11.5,9}
    	};
    	
    	double timeToComplete = 4;
    	
    	addSequential(new AutoPath(path, timeToComplete,true));	//Drive is in inches
    	addSequential(new Switch());
    	
	}

	

}
