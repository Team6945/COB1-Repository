package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP2LSwitchTwice extends CommandGroup {

	public AP2LSwitchTwice() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	addSequential(new AP2LSwitch());
    	addSequential(new WristControl(2, true)); //up
    	
    	double[][] path = {
    			{11,18}
				,{10,18}
    	};
    	
    	double timeToComplete = 1.1;
    	
    	addSequential(new AutoPath(path, timeToComplete,false));	//Drive is in inches// backward
    	
    	addParallel(new WristControl(2, false));//down
    	addSequential(new Turn(90));
    	addParallel(new BSInOrOut(0.5,3));
    	
    	double[][] path2 = {
    			{10,18}
				,{10,15}
    	};
    	
    	double timeToComplete2 = 1.1;
    	
    	addSequential(new AutoPath(path2, timeToComplete2,true)); //forward
    	addParallel(new BSInOrOut(0.2,3));
    	addParallel(new WristControl(2,true));//up
    	addSequential(new AutoPath(path2, timeToComplete2,false)); //second one, backwards
    	addSequential(new TurnSetpoint(0));
    	addSequential(new AutoPath(path, timeToComplete,true)); //first one, forwards
    	addSequential(new Switch());
    	
    	
	}

	

}
