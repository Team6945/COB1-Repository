package org.usfirst.frc6945.COB1_3.commands;

import org.usfirst.frc6945.COB1_3.Robot;

import edu.wpi.first.wpilibj.command.CommandGroup;



public class AP3RSwitch extends CommandGroup {

	public AP3RSwitch() {

    	requires(Robot.blockSucker);
    	requires(Robot.drivetrain);
    	requires(Robot.lift);
    	requires(Robot.winch);
    	requires(Robot.wristPID);
    	
    	double[][] path = {
    			{1,4}
				,{14,4}
				,{14,7}
    	};
    	
    	double timeToComplete = 5;
    	
    	addSequential(new AutoPath(path, timeToComplete,true));	//Drive is in inches
    	addSequential(new Switch());
    	
	}

	

}
