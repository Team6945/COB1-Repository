package org.usfirst.frc6945.COB1_3;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.Button;

public class POVButton extends Button {

	Joystick joystick;
	int num;
	
	public POVButton(Joystick controller, int num) {
		this.joystick = controller;
		this.num = num;
	}

	@Override
	public boolean get() {
		// TODO Auto-generated method stub
		return joystick.getPOV() >= 0;
	}

}
